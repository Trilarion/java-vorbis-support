readme.txt
----------

Preliminary install instructions:
- copy *.jar to .../jre/lib/ext/
- copy libtritonusvorbis.so* to .../jre/lib/ext/i386/


Test with AudioEncoder from jsresources.org:

java AudioEncoder -e VORBIS -t Vorbis -T ogg inputfile outputfile
