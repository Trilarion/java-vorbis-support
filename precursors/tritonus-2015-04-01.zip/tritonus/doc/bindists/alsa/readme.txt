readme.txt
----------

Preliminary install instructions:
- copy *.jar to .../jre/lib/ext/
- copy libtritonusalsa.so* to.../jre/lib/ext/i386/
- copy libtritonuscommon.so* to /usr/lib/ (or maybe /usr/local/lib/)
