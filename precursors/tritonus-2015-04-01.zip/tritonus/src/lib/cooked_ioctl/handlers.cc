/*
 *	handlers.cc
 */


#include	"../common/HandleFieldHandler.cc"


template class HandleFieldHandler<int>;



/*** handlers.cc ***/
